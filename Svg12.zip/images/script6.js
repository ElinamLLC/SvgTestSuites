document.getElementById('c6').setAttributeNS(null, 'fill','green');
