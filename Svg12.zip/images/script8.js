document.getElementById('c7').setAttributeNS(null, 'fill','green');
