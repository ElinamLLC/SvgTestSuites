document.getElementById('c3').setAttributeNS(null, 'fill','red');
