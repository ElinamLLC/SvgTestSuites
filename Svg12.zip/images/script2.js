document.getElementById('c2').setAttributeNS(null, 'fill','red');
