document.getElementById('c4').setAttributeNS(null, 'fill','red');
