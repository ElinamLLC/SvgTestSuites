document.getElementById('c8').setAttributeNS(null, 'fill','green');
